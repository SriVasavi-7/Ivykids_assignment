import mongoose from "mongoose";


export const connect = async () => {

    await mongoose.connect("mongodb+srv://chandusrivasavi1:chandusrivasavi1@cluster0.ao595t0.mongodb.net/?retryWrites=true&w=majority")
}

